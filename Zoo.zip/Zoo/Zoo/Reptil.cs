﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zootest
{
    public class Reptil: Tier
    {
        int anzahl;
        static int anzahlreptilien;
        double futtervorrat;
        string nahrung;
        string name;
        public bool futtererfolg = false;//nur zum Testen!
        public bool futtermisserfolg = false;//nur zum Testen!

        public Reptil(string name, string nahrung, int anzahl) : base(anzahl)
        {
            this.name = name;
            this.nahrung = nahrung;
            this.anzahl = anzahl;
            anzahlreptilien += anzahl;
            futtervorrat = anzahl * 30;
        }
        public static int Anzahlreptilien
        {
            get { return anzahlreptilien; }
        }
        public int Anzahl()
        {
            return anzahl;
        }
        public void Fuettern(double kilofutter)
        {
            Console.Clear();
            if (kilofutter <= futtervorrat)
            {
                futtervorrat -= kilofutter;
                Console.WriteLine("Die Tiere wurden mit {0} Kilo {1} gefüttert.\nNeuer Futtervorrat: {2} Kilo", kilofutter, nahrung, futtervorrat);
                //Console.ReadLine()-->im Programm selbst, sonst funktioniert Test nicht!;
                futtererfolg = true;
            }
            else
            {
                Console.WriteLine("Nicht genügend Futter vorhanden.");
                //Console.ReadLine()-->im Programm selbst, sonst funktioniert Test nicht!;
                futtermisserfolg = true;
            }
        }
    }
}
