﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zootest
{
    public class Tier
    {
        static int anzahltiere;

        public Tier(int anzahl)
        {
            for (int i = 0; i < anzahl; i++)
            {
                anzahltiere++;
            }
        }
        public static int Anzahltiere
        {
            get { return anzahltiere; }
        }
    }
}
