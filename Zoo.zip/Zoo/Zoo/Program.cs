﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zootest
{
    class Program
    {
        static void Trennen()
        {
            Console.WriteLine("---------------------------------------------------------");
        }
        static void Eingabefehler()
        {
            Console.WriteLine("Ungültige Eingabe!");
            Console.ReadLine();
            Console.Clear();
        }
        static void Auswahl(string frage, string a, string b, string c, string d)
        {
            Console.WriteLine("{0}\nTippe a für {1}\nTippe b für {2}\nTippe c für {3}\nTippe d für {4}", frage, a, b, c, d);
        }
        static void Auswahl(string frage, string a, string b, string c)
        {
            Console.WriteLine("{0}\nTippe a für {1}\nTippe b für {2}\nTippe c für {3}", frage, a, b, c);
        }
        static void Main(string[] args)
        {
            Random rnd = new Random();
            //Säugetiere:
            Saeugetier Elefant = new Saeugetier("Elefant", "Pflanzen", rnd.Next(20, 30));
            Saeugetier Tiger = new Saeugetier("Tiger", "Fleisch", rnd.Next(5, 10));
            Saeugetier Wolf = new Saeugetier("Wolf", "Fleisch", rnd.Next(20, 25));

            //Vögel:
            Vogel Adler = new Vogel("Adler", "Fleisch", rnd.Next(5, 30));
            Vogel Falke = new Vogel("Falke", "Fleisch", rnd.Next(20, 35));
            Vogel Papagei = new Vogel("Papagei", "Pflanzen", rnd.Next(20, 50));

            //Reptilien:
            Reptil Krokodil = new Reptil("Krokodil", "Fleisch", rnd.Next(30, 60));
            Reptil Schlange = new Reptil("Schlange", "Fleisch", rnd.Next(50, 120));
            Reptil Echse = new Reptil("Echse", "Pflanzen", rnd.Next(100, 200));

            //Fische:
            Fisch Hai = new Fisch("Hai", "Fisch", rnd.Next(20, 40));
            Fisch Karpfen = new Fisch("Karpfen", "Pflanzen", rnd.Next(100, 400));
            Fisch Clownfisch = new Fisch("Clownfisch", "Pflanzen", rnd.Next(200, 400));

            //Besucher:
            int kinderzahl = rnd.Next(500, 5000);
            int erwachsenenzahl = rnd.Next(300, 4000);
            int besuchergesamt = kinderzahl + erwachsenenzahl;

            //Eintrittspreise:
            double eintrittkind = 6.5;
            double eintritterwachsener = 12.5;

            //Einnahmen:
            double einnahmenkinder = kinderzahl * eintrittkind;
            double einnahmenerwachsener = erwachsenenzahl * eintritterwachsener;
            double einnahmengesamt = einnahmenerwachsener + einnahmenkinder;

            //Begrüssung:
            Console.WriteLine("Willkommen im Zooprogramm!");
            string hauptaktion;
            do
            {
                Auswahl("Was möchtest du tun?", "Tierprogramm", "Besucherprogramm", "Programm beenden");
                hauptaktion = Console.ReadLine();
                switch (hauptaktion)
                {
                    case "a":
                        //Tierprogramm
                        string tieraktion;
                        do
                        {
                            Console.Clear();
                            Auswahl("Was möchtest du tun?", "Zootiere auflisten", "Zootiere füttern", "Zurück zum Hauptmenü");
                            tieraktion = Console.ReadLine();
                            if(tieraktion == "a")
                            {
                                Console.Clear();
                                //Zootiere auflisten
                                Console.WriteLine("Gesamtanzahl Tiere: {0}", Tier.Anzahltiere);
                                Trennen();
                                Console.WriteLine("Säugetiere: Gesamt: {0}", Saeugetier.Anzahlsaeugetiere);
                                Console.WriteLine("Elefanten: {0}", Elefant.Anzahl());
                                Console.WriteLine("Tiger: {0}", Tiger.Anzahl());
                                Console.WriteLine("Wölfe: {0}", Wolf.Anzahl());
                                Trennen();
                                Console.WriteLine("Vögel: Gesamt: {0}", Vogel.Anzahlvoegel);
                                Console.WriteLine("Adler: {0}", Adler.Anzahl());
                                Console.WriteLine("Falken: {0}", Falke.Anzahl());
                                Console.WriteLine("Papageien: {0}", Papagei.Anzahl());
                                Trennen();
                                Console.WriteLine("Reptilien: Gesamt: {0}", Reptil.Anzahlreptilien);
                                Console.WriteLine("Krokodile: {0}", Krokodil.Anzahl());
                                Console.WriteLine("Schlangen: {0}", Schlange.Anzahl());
                                Console.WriteLine("Echsen: {0}", Echse.Anzahl());
                                Trennen();
                                Console.WriteLine("Fische: Gesamt: {0}", Fisch.Anzahlfische);
                                Console.WriteLine("Haie: {0}", Hai.Anzahl());
                                Console.WriteLine("Karpfen: {0}", Karpfen.Anzahl());
                                Console.WriteLine("Clownfische: {0}", Clownfisch.Anzahl());
                                Trennen();
                                Console.ReadLine();
                                Console.Clear();

                            }
                            else if(tieraktion == "b")
                            {
                                Console.Clear();
                                //Tiere füttern
                                Auswahl("Wähle eine Tierklasse", "Säugetiere", "Vögel", "Reptilien", "Fische");
                                string tierwahl1 = Console.ReadLine();
                                double kilofutter = 0;
                                if(tierwahl1 == "a")
                                {
                                    //Säugetiere
                                    Console.Clear();
                                    Auswahl("Welche Tiere sollen gefüttert werden?", "Elefanten", "Tiger", "Wölfe");
                                    string tierwahl2 = Console.ReadLine();
                                    do
                                    {
                                        Console.Clear();
                                        Console.WriteLine("Wieviel Kilo Futter möchtest du verfüttern?");
                                        try
                                        {
                                            kilofutter = Convert.ToDouble(Console.ReadLine());
                                        }
                                        catch(Exception)
                                        {
                                            Eingabefehler();
                                        }
                                    } while (kilofutter <= 0);
                                    if(tierwahl2 == "a")
                                    {
                                        Elefant.Fuettern(kilofutter);
                                        Console.ReadLine();
                                    }
                                    else if(tierwahl2 == "b")
                                    {
                                        Tiger.Fuettern(kilofutter);
                                        Console.ReadLine();
                                    }
                                    else if(tierwahl2 == "c")
                                    {
                                        Wolf.Fuettern(kilofutter);
                                        Console.ReadLine();
                                    }
                                    else
                                    {
                                        Eingabefehler();
                                    }
                                }
                                else if(tierwahl1 == "b")
                                {
                                    //Vögel
                                    Console.Clear();
                                    Auswahl("Welche Tiere sollen gefüttert werden?", "Adler", "Falken", "Papageien");
                                    string tierwahl2 = Console.ReadLine();
                                    do
                                    {
                                        Console.Clear();
                                        Console.WriteLine("Wieviel Kilo Futter möchtest du verfüttern?");
                                        try
                                        {
                                            kilofutter = Convert.ToDouble(Console.ReadLine());
                                        }
                                        catch (Exception)
                                        {
                                            Eingabefehler();
                                        }
                                    } while (kilofutter <= 0);
                                    if (tierwahl2 == "a")
                                    {
                                        Adler.Fuettern(kilofutter);
                                        Console.ReadLine();
                                    }
                                    else if (tierwahl2 == "b")
                                    {
                                        Falke.Fuettern(kilofutter);
                                        Console.ReadLine();
                                    }
                                    else if (tierwahl2 == "c")
                                    {
                                        Papagei.Fuettern(kilofutter);
                                        Console.ReadLine();
                                    }
                                    else
                                    {
                                        Eingabefehler();
                                    }
                                }
                                else if(tierwahl1 == "c")
                                {
                                    //Reptilien
                                    Console.Clear();
                                    Auswahl("Welche Tiere sollen gefüttert werden?", "Krokodile", "Schlangen", "Echsen");
                                    string tierwahl2 = Console.ReadLine();
                                    do
                                    {
                                        Console.Clear();
                                        Console.WriteLine("Wieviel Kilo Futter möchtest du verfüttern?");
                                        try
                                        {
                                            kilofutter = Convert.ToDouble(Console.ReadLine());
                                        }
                                        catch (Exception)
                                        {
                                            Eingabefehler();
                                        }
                                    } while (kilofutter <= 0);
                                    if (tierwahl2 == "a")
                                    {
                                        Krokodil.Fuettern(kilofutter);
                                        Console.ReadLine();
                                    }
                                    else if (tierwahl2 == "b")
                                    {
                                        Schlange.Fuettern(kilofutter);
                                        Console.ReadLine();
                                    }
                                    else if (tierwahl2 == "c")
                                    {
                                        Echse.Fuettern(kilofutter);
                                        Console.ReadLine();
                                    }
                                    else
                                    {
                                        Eingabefehler();
                                    }
                                }
                                else if(tierwahl1 == "d")
                                {
                                    //Fische
                                    Console.Clear();
                                    Auswahl("Welche Tiere sollen gefüttert werden?", "Haie", "Karpfen", "Clownfische");
                                    string tierwahl2 = Console.ReadLine();
                                    do
                                    {
                                        Console.Clear();
                                        Console.WriteLine("Wieviel Kilo Futter möchtest du verfüttern?");
                                        try
                                        {
                                            kilofutter = Convert.ToDouble(Console.ReadLine());
                                        }
                                        catch (Exception)
                                        {
                                            Eingabefehler();
                                        }
                                    } while (kilofutter <= 0);
                                    if (tierwahl2 == "a")
                                    {
                                        Hai.Fuettern(kilofutter);
                                        Console.ReadLine();
                                    }
                                    else if (tierwahl2 == "b")
                                    {
                                        Karpfen.Fuettern(kilofutter);
                                        Console.ReadLine();
                                    }
                                    else if (tierwahl2 == "c")
                                    {
                                        Clownfisch.Fuettern(kilofutter);
                                        Console.ReadLine();
                                    }
                                    else
                                    {
                                        Eingabefehler();
                                    }
                                }
                                else
                                {
                                    Eingabefehler();
                                }
                                Console.Clear();
                            }
                            else if(tieraktion == "c")
                            {
                                Console.Clear();
                                //Hauptmenü
                                break;
                            }
                            else
                            {
                                Eingabefehler();
                            }
                        }
                        while (tieraktion != "c");
                        break;
                    case "b":
                        //Besucherprogramm
                        string besucherwahl;
                        do
                        {
                            Console.Clear();
                            Auswahl("Was möchtest du tun?", "Besucher auflisten", "Heutige Einnahmen auflisten", "Zurück zum Hauptmenü");
                            besucherwahl = Console.ReadLine();
                            Console.Clear();
                            if(besucherwahl == "a")
                            {
                                //Besucher auflisten
                                Console.WriteLine("Besucher gesamt: {0}", besuchergesamt);
                                Console.WriteLine("Anzahl Kinder: {0}\nAnzahl Erwachsene: {1}", kinderzahl, erwachsenenzahl);
                                Console.ReadLine();
                                Console.Clear();
                            }
                            else if(besucherwahl == "b")
                            {
                                //Heutige Einnahmen
                                Console.WriteLine("Heutige Einnahmen gesamt: {0} Franken\nEinnahmen von Kindern: {1} Franken\nEinnahmen von Erwachsenen: {2} Franken", einnahmengesamt, einnahmenkinder, einnahmenerwachsener);
                                Console.ReadLine();
                                Console.Clear();
                            }
                            else if(besucherwahl == "c")
                            {
                                Console.Clear();
                                break;
                            }
                            else
                            {
                                Eingabefehler();
                            }
                        }
                        while (besucherwahl != "c");
                        Console.Clear();
                        break;
                    case "c":
                        //Programmende
                        break;
                    default:
                        Eingabefehler();
                        break;
                }

            }
            while (hauptaktion != "c");

        }
    }
}
