﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Zootest;

namespace Unittest1
{
    [TestClass]
    public class UnitTest1
    {
        //Tests für Anzahl:
        [TestMethod]
        public void Anzahlsaeugetieretest()
        {
            //Test Anzahl Säugetiere:
            Saeugetier Testsaeugetier1 = new Saeugetier("Testsäugetier1", "Testnahrung", 10);
            int expected1 = 10;
            int actual1 = Saeugetier.Anzahlsaeugetiere;
            Assert.AreEqual(expected1, actual1, 0.001, "Die Anzahl Säugetiere stimmt nicht!");
            //Test Anzahl von Objekt:
            int expected2 = 10;
            int actual2 = Testsaeugetier1.Anzahl();
            Assert.AreEqual(expected2, actual2, 0.001, "Die Anzahl vom Säugetierobjekt stimmt nicht!");
        }
        [TestMethod] 
        public void Anzahlvoegeltest()
        {
            //Test Anzahl Voegel:
            Vogel Testvogel1 = new Vogel("Testvogel1", "Testnahrung", 10);
            int expected1 = 10;
            int actual1 = Vogel.Anzahlvoegel;
            Assert.AreEqual(expected1, actual1, 0.001, "Anzahl Vögel stimmt nicht!");
            //Test Anzahl von Objekt:
            int expected2 = 10;
            int actual2 = Testvogel1.Anzahl();
            Assert.AreEqual(expected2, actual2, 0.001, "Die Anzahl vom Vogelobjekt stimmt nicht!");
        }
        [TestMethod]
        public void Anzahlreptilientest()
        {
            //Test Anzahl Reptilien:
            Reptil Testreptil1 = new Reptil("Testreptil1", "Testnahrung", 10);
            int expected1 = 10;
            int actual1 = Reptil.Anzahlreptilien;
            Assert.AreEqual(expected1, actual1, 0.001, "Anzahl Reptilien stimmt nicht!");
            //Test Anzahl von Objekt:
            int expected2 = 10;
            int actual2 = Testreptil1.Anzahl();
            Assert.AreEqual(expected2, actual2, 0.001, "Die Anzahl vom Reptilobjekt stimmt nicht!");
        }
        [TestMethod]
        public void Anzahlfischetest()
        {
            //Test Anzahl Fische:
            Fisch Testfisch1 = new Fisch("Testfisch1", "Testnahrung", 10);
            int expected1 = 10;
            int actual1 = Fisch.Anzahlfische;
            Assert.AreEqual(expected1, actual1, 0.001, "Anzahl Fische stimmt nicht!");
            //Test Anzahl von Objekt:
            int expected2 = 10;
            int actual2 = Testfisch1.Anzahl();
            Assert.AreEqual(expected2, actual2, 0.001, "Die Anzahl vom Fischobjekt stimmt nicht!");
        }
        [TestMethod] 
        public void Anzahtieretest()
        {
            //Gesamtanzahl der Tiere testen:
            int expected = 40;
            int actual = Tier.Anzahltiere;
            Assert.AreEqual(expected, actual, 0.001, "Gesamtanzahl Tiere stimmt nicht!");
        }
        //Tests zum Füttern:
        [TestMethod]
        public void Saeugetierfüttern()
        {
            //Füttern von Säugetieren testen:
            Saeugetier Testsaeugetier = new Saeugetier("Test", "test", 10);
            //Testen ob Füttern mit kilofutter < futtervorrat funktioniert:
            Testsaeugetier.Fuettern(300);
            bool expected1 = true;
            bool actual1 = Testsaeugetier.futtererfolg;
            Assert.AreEqual(expected1, actual1, "Füttern (kilofutter < futtervorrat) nicht erfolgreich!");
            //Testen ob Füttern mit kilofutter > futtervorrat funktioniert:
            Testsaeugetier.Fuettern(5000);
            bool expected2 = true;
            bool actual2 = Testsaeugetier.futtermisserfolg;
            Assert.AreEqual(expected2, actual2, "Füttern (kilofutter > futtervorrat) nicht erfolgreich!");
        }
        [TestMethod]
        public void Voegelfüttern()
        {
            //Füttern von Vögel testen:
            Vogel Testvogel = new Vogel("Test", "test", 10);
            //Testen ob Füttern mit kilofutter < futtervorrat funktioniert:
            Testvogel.Fuettern(300);
            bool expected1 = true;
            bool actual1 = Testvogel.futtererfolg;
            Assert.AreEqual(expected1, actual1, "Füttern (kilofutter < futtervorrat) nicht erfolgreich!");
            //Testen ob Füttern mit kilofutter > futtervorrat funktioniert:
            Testvogel.Fuettern(5000);
            bool expected2 = true;
            bool actual2 = Testvogel.futtermisserfolg;
            Assert.AreEqual(expected2, actual2, "Füttern (kilofutter > futtervorrat) nicht erfolgreich!");
        }
        [TestMethod]
        public void Reptilienfüttern()
        {
            //Füttern von Reptilien testen:
            Reptil Testreptil = new Reptil("Test", "test", 10);
            //Testen ob Füttern mit kilofutter < futtervorrat funktioniert:
            Testreptil.Fuettern(300);
            bool expected1 = true;
            bool actual1 = Testreptil.futtererfolg;
            Assert.AreEqual(expected1, actual1, "Füttern (kilofutter < futtervorrat) nicht erfolgreich!");
            //Testen ob Füttern mit kilofutter > futtervorrat funktioniert:
            Testreptil.Fuettern(5000);
            bool expected2 = true;
            bool actual2 = Testreptil.futtermisserfolg;
            Assert.AreEqual(expected2, actual2, "Füttern (kilofutter > futtervorrat) nicht erfolgreich!");
        }
        [TestMethod]
        public void Fischefüttern()
        {
            //Füttern von Fischen testen:
            Fisch Testfisch = new Fisch("Test", "test", 10);
            //Testen ob Füttern mit kilofutter < futtervorrat funktioniert:
            Testfisch.Fuettern(300);
            bool expected1 = true;
            bool actual1 = Testfisch.futtererfolg;
            Assert.AreEqual(expected1, actual1, "Füttern (kilofutter < futtervorrat) nicht erfolgreich!");
            //Testen ob Füttern mit kilofutter > futtervorrat funktioniert:
            Testfisch.Fuettern(5000);
            bool expected2 = true;
            bool actual2 = Testfisch.futtermisserfolg;
            Assert.AreEqual(expected2, actual2, "Füttern (kilofutter > futtervorrat) nicht erfolgreich!");
        }
    }
}
